import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show SystemSound, SystemSoundType;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:audioplayers/audioplayers.dart';
import '../providers.dart';
import '../services/llm_service.dart';
import '../widgets/typing_dots.dart';
import '../widgets/thinking_backdrop.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final AudioRecorder _recorder = AudioRecorder();
  final stt.SpeechToText _stt = stt.SpeechToText('Ask me anything!', style: theme.textTheme.bodyLarge),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Tap the mic button to speak, and then tap to send',
                          style: theme.textTheme.bodyMedium!.copyWith(color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                // Always show transcript card
                Text('Transcript', style: theme.textTheme.titleLarge),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white24),
                  ),
                  child: Text(
                    transcript.isEmpty ? (recording ? 'Listening…' : '—') : transcript,
                  ),
                ),
                const SizedBox(height: 16),
                // Answer block with typing dots
                Text('Answer', style: theme.textTheme.titleLarge),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white24),
                  ),
                  child: answering
                    ? Row(children:[const TypingDots(), const SizedBox(width:8), const Text('Thinking…')])
                    : ConstrainedBox(
                        constraints: const BoxConstraints(maxHeight: 320),
                        child: Scrollbar(
                          thumbVisibility: true,
                          child: SingleChildScrollView(
                            child: Text(reply.isEmpty ? '—' : reply),
                          ),
                        ),
                      ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.only(bottom: 24),
            child: Center(
              child: GestureDetector(
                onTap: () async { try { await HapticFeedback.mediumImpact(); } catch (_) {} await _toggleRecord(); },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  curve: Curves.easeOut,
                  height: recording ? 156 : 148,
                  width: recording ? 156 : 148,
                  decoration: BoxDecoration(
                    color: recording ? theme.colorScheme.secondary : theme.colorScheme.primary,
                    shape: BoxShape.circle,
                    boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 24)],
                  ),
                  child: Icon(
                    recording ? Icons.stop : Icons.mic,
                    size: 68,
                    color: theme.colorScheme.onPrimary,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
