import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'services/secure_storage.dart';

final openAiKeyProvider = StateNotifierProvider<OpenAiKeyController, String?>(
  (ref) => OpenAiKeyController()..load(),
);

class OpenAiKeyController extends StateNotifier<String?> {
  OpenAiKeyController() : super(null);
  Future<void> load() async {
    state = await SecureStore.getOpenAIKey();
  }
  Future<void> save(String key) async {
    await SecureStore.saveOpenAIKey(key);
    state = key.trim();
  }
}

final listeningProvider = StateProvider<bool>((ref) => false);
final transcriptProvider = StateProvider<String>((ref) => '');
final replyProvider = StateProvider<String>((ref) => '');

final answeringProvider = StateProvider<bool>((ref) => false);


import 'package:shared_preferences/shared_preferences.dart';

final voiceProvider = StateNotifierProvider<VoiceController, String>(
  (ref) => VoiceController()..load(),
);

class VoiceController extends StateNotifier<String> {
  VoiceController() : super('alloy');
  static const _key = 'openai_tts_voice';
  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    state = prefs.getString(_key) ?? 'alloy';
  }
  Future<void> save(String voice) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, voice);
    state = voice;
  }
}
