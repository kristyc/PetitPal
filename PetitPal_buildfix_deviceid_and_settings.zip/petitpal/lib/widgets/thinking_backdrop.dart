import 'dart:math' as math;
import 'package:flutter/material.dart';

class ThinkingBackdrop extends StatefulWidget {
  const ThinkingBackdrop({super.key, required this.active});
  final bool active;

  @override
  State<ThinkingBackdrop> createState() => _ThinkingBackdropState();
}

class _ThinkingBackdropState extends State<ThinkingBackdrop>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _t;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 10));
    _t = CurvedAnimation(parent: _c, curve: Curves.easeInOut);
  }

  @override
  void didUpdateWidget(covariant ThinkingBackdrop oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.active && !_c.isAnimating) {
      _c.repeat(reverse: true);
    } else if (!widget.active && _c.isAnimating) {
      _c.stop();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final reduceMotion = mq.disableAnimations || mq.accessibleNavigation;
    if (reduceMotion) {
      return IgnorePointer(child: Container(color: widget.active ? const Color(0xFF121826) : const Color(0xFF0B0F14)));
    }
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _t,
        builder: (_, __) {
          double t = _t.value;
          Color lerp(Color a, Color b, double m) => Color.lerp(a, b, m)!;
          // Deep contrasting palette for accessibility
          const baseA = Color(0xFF0A0F1E); // deep twilight
          const baseB = Color(0xFF081220); // near-black blue
          const accA  = Color(0xFF0E6BA8); // teal-blue
          const accB  = Color(0xFF8FDBFF); // cyan
          final a = lerp(baseA, accA, (math.sin(t * math.pi) + 1) / 2);
          final b = lerp(baseB, accB, (math.sin((t + 0.5) * math.pi) + 1) / 2);
          final begin = Alignment(-1 + 2 * t, -0.8);
          final end   = Alignment(1 - 2 * t, 0.8);
          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: begin, end: end,
                colors: [a.withOpacity(0.9), b.withOpacity(0.9)],
              ),
            ),
            child: Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  colors: [Colors.transparent, Color(0xAA000000)],
                  radius: 1.2,
                  center: Alignment(0.8, -0.8),
                  stops: [0.7, 1.0],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
