/// Centralized config for PetitPal.
class AppConfig {
  /// Cloudflare Worker (production)
  static const String workerBaseUrl = 'https://petitpal-api.kristyc.workers.dev';
  static const String workerFilename = 'https://petitpal-api.kristyc.workers.dev/worker.js';

  /// Cloudflare KV (future use)
  /// Namespace: petitpal-kv
  /// Binding variable name: petitpal-kv
  /// (No persistence used in this MVP; kept here for dev reference.)
  static const String kvNamespace = 'petitpal-kv';
  static const String kvBinding = 'petitpal-kv';

  /// Default model used by the Worker for chat responses.
  static const String defaultModel = 'gpt-4o-mini';
}
