import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:audioplayers/audioplayers.dart';
import 'package:volume_controller/volume_controller.dart';
import 'package:flutter/services.dart' show SystemSound, SystemSoundType;
import '../providers.dart';
import '../services/llm_service.dart';
import '../widgets/typing_dots.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final AudioRecorder _recorder = AudioRecorder();
  final stt.SpeechToText _stt = stt.SpeechToText();
  bool _sttAvailable = false;
  final AudioPlayer _player = AudioPlayer();
  int _session = 0;
  final VolumeController _vol = VolumeController();
  double? _origVolume;
  bool _mutedForStt = false;

  @override
  void initState() {
    _player.setReleaseMode(ReleaseMode.stop);
    super.initState();
    _initSpeech();
  }

  Future<void> _initSpeech() async {
    try {
      _sttAvailable = await _stt.initialize(
        onStatus: (s) => debugPrint('stt status: ' + s),
        onError: (e) => debugPrint('stt error: ' + e.errorMsg),
      );
      debugPrint('stt available: $_sttAvailable');
    } catch (e) {
      debugPrint('stt init failed: $e');
    }
  }

  Future<void> _muteMediaForSttAfterStart() async {
    // Let the system start-beep happen, then mute media so end-beep is inaudible
    await Future.delayed(const Duration(milliseconds: 400));
    try {
      _origVolume ??= await _vol.getVolume();
      await _vol.setVolume(0.0);
      _mutedForStt = true;
      debugPrint('Media volume muted for STT (orig: ' + (_origVolume?.toStringAsFixed(2) ?? 'n/a') + ')');
    } catch (e) {
      debugPrint('Volume mute failed: $e');
    }
  }

  Future<void> _restoreMediaVolumeAndPlayEndChime() async {
    try {
      if (_mutedForStt && _origVolume != null) {
        await _vol.setVolume(_origVolume!.clamp(0.0, 1.0));
        _mutedForStt = false;
        debugPrint('Media volume restored to ' + _origVolume!.toString());
      }
      // Play an explicit end sound
      await SystemSound.play(SystemSoundType.click);
    } catch (e) {
      debugPrint('Volume restore/chime failed: $e');
    }
  }

    try {
      _sttAvailable = await _stt.initialize(
        onStatus: (s) => debugPrint('stt status: ' + s),
        onError: (e) => debugPrint('stt error: ' + e.errorMsg),
      );
      debugPrint('stt available: $_sttAvailable');
    } catch (e) {
      debugPrint('stt init failed: $e');
    }
  }

  @override
  void dispose() {
    try { _stt.stop(); } catch (_) {}
    _player.dispose();
    super.dispose();
  }

  Future<void> _toggleRecord() async {
    final recording = ref.read(listeningProvider);
    if (!recording) {
      // New session: stop any ongoing playback and bump token
      try {
        final int reqSession = _session; await _player.stop(); } catch (_) {}
      _session++;
      // Start
      await Permission.microphone.request();
      final has = await _recorder.hasPermission();
      if (!has) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Mic permission denied')),
          );
          // Mute media so OS 'end listening' earcon won't be heard while you speak
          unawaited(_muteMediaForSttAfterStart());
        }
        return;
      }
      final dir = await getTemporaryDirectory();
      final filePath = '${dir.path}/petitpal_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 128000,
          sampleRate: 44100,
        ),
        path: filePath,
      );
      // Live STT for on-screen transcript
      if (!_sttAvailable) {
        try {
        final int reqSession = _session;
        ref.read(answeringProvider.notifier).state = true; _sttAvailable = await _stt.initialize(); } catch (_) {}
      }
      if (_sttAvailable) {
        try {
        final int reqSession = _session;
        ref.read(answeringProvider.notifier).state = true;
          final sys = await _stt.systemLocale();
          final loc = sys?.localeId;
          await _stt.listen(
            onResult: (res) {
              ref.read(transcriptProvider.notifier).state = res.recognizedWords;
            },
            listenMode: stt.ListenMode.dictation,
            partialResults: true,
            localeId: loc,
            pauseFor: const Duration(seconds: 10),
            listenFor: const Duration(minutes: 5),
          );
          // Mute media so OS 'end listening' earcon won't be heard while you speak
          unawaited(_muteMediaForSttAfterStart());
        } catch (e) {
          debugPrint('stt.listen failed: $e');
        }
      }
      ref.read(listeningProvider.notifier).state = true;
      ref.read(transcriptProvider.notifier).state = '';
      ref.read(replyProvider.notifier).state = '';
    } else {
      // Stop
      ref.read(listeningProvider.notifier).state = false;
      try {
        final int reqSession = _session;
        ref.read(answeringProvider.notifier).state = true; await _stt.stop(); } catch (_) {}
      final path = await _recorder.stop();
      if (path == null) return;
      final file = File(path);
      final bytes = await file.readAsBytes();

      final key = ref.read(openAiKeyProvider);
      if (key == null || key.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Please set your OpenAI key in Settings.')),
          );
          // Mute media so OS 'end listening' earcon won't be heard while you speak
          unawaited(_muteMediaForSttAfterStart());
        }
        return;
      }
      try {
        final int reqSession = _session;
        ref.read(answeringProvider.notifier).state = true;
        final res = await LlmService.voiceChat(audio: bytes, mimeType: 'audio/m4a', openAiApiKey: key);
        if (reqSession == _session) {
          // Keep live text if OpenAI transcript missing; otherwise show OpenAI's transcript
          final live = ref.read(transcriptProvider);
          ref.read(transcriptProvider.notifier).state = res.transcript ?? live;
          ref.read(replyProvider.notifier).state = res.reply ?? '';
        }

        // Prefer OpenAI TTS audio for playback
        ref.read(answeringProvider.notifier).state = false;
        if (reqSession == _session && !ref.read(listeningProvider) && res.audioBytes != null && res.audioBytes!.isNotEmpty) {
          final dir = await getTemporaryDirectory();
          final p = '${dir.path}/reply_${DateTime.now().millisecondsSinceEpoch}.mp3';
          final f = File(p);
          await f.writeAsBytes(res.audioBytes!);
          await _player.stop();
          await _player.setVolume(1.0);
          await _player.play(DeviceFileSource(p));
        }
      } catch (e) {
        ref.read(answeringProvider.notifier).state = false;
        ref.read(replyProvider.notifier).state = 'Error: $e';
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('LLM error: $e')));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final recording = ref.watch(listeningProvider);
    final transcript = ref.watch(transcriptProvider);
    final reply = ref.watch(replyProvider);
    final answering = ref.watch(answeringProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('PetitPal'),
        actions: [
          IconButton(
            onPressed: () => Navigator.of(context).pushNamed('/settings'),
            icon: const Icon(Icons.settings),
            tooltip: 'Settings',
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.local_florist, size: 56),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Text(
                                'Ask anything about food & daily nutrition.',
                                style: theme.textTheme.bodyLarge,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Text('Tap to start, speak, tap again to send.
Live transcript shows as you talk.',style: theme.textTheme.bodyMedium!.copyWith(color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                // Always show transcript card
                Text('Transcript', style: theme.textTheme.titleLarge),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white24),
                  ),
                  child: Text(
                    transcript.isEmpty ? (recording ? 'Listening…' : '—') : transcript,
                  ),
                ),
                const SizedBox(height: 16),
                
                Text('Answer', style: theme.textTheme.titleLarge),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white24),
                  ),
                  child: answering
                    ? Row(children:[const TypingDots(), const SizedBox(width:8), const Text('Thinking…')])
                    : Text(reply.isEmpty ? '—' : reply),
                ),

              ],
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.only(bottom: 24),
            child: Center(
              child: GestureDetector(
                onTap: _toggleRecord,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  curve: Curves.easeOut,
                  height: recording ? 96 : 88,
                  width: recording ? 96 : 88,
                  decoration: BoxDecoration(
                    color: recording ? theme.colorScheme.secondary : theme.colorScheme.primary,
                    shape: BoxShape.circle,
                    boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 24)],
                  ),
                  child: Icon(
                    recording ? Icons.stop : Icons.mic,
                    size: 44,
                    color: theme.colorScheme.onPrimary,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
