import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import '../config.dart';
import '../providers.dart';
import '../services/llm_service.dart';

class DiagnosticsScreen extends ConsumerStatefulWidget {
  const DiagnosticsScreen({super.key});
  @override
  ConsumerState<DiagnosticsScreen> createState() => _DiagnosticsScreenState();
}

class _DiagnosticsScreenState extends ConsumerState<DiagnosticsScreen> {
  final _log = <String>[];
  bool _running = false;

  void _add(String s) {
    debugPrint('[Diag] ' + s);
    setState(() => _log.add(s));
  }

  Future<void> _runChecks() async {
    if (_running) return;
    setState(() => _running = true);
    _log.clear();

    try {
      _add('Worker base: ' + AppConfig.normalizedWorkerBaseUrl);
      // 1) Key present
      final key = ref.read(openAiKeyProvider);
      if (key == null || key.isEmpty) {
        _add('❌ OpenAI key: NOT SET (go to Settings)');
        setState(() => _running = false);
        return;
      } else {
        _add('✅ OpenAI key: present (length ${key.length})');
      }

      // 2) Worker connectivity via /api/chat (text ping)
      try {
      _add('Worker base: ' + AppConfig.normalizedWorkerBaseUrl);
        final r = await http.post(
          Uri.parse('${AppConfig.normalizedWorkerBaseUrl}/api/chat'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + key.trim(),
          },
          body: '{"text":"diagnostic ping","model":"'+AppConfig.defaultModel+'"}',
        );
        _add('HTTP POST /api/chat -> ' + r.statusCode.toString());
        _add('Body (first 300): ' + (r.body.length > 300 ? r.body.substring(0,300) : r.body));
        if (r.statusCode != 200) {
          _add('❌ /api/chat failed. Check worker logs and Authorization header.');
          setState(() => _running = false);
          return;
        } else {
          _add('✅ /api/chat reachable on ' + AppConfig.normalizedWorkerBaseUrl);
        }
      } catch (e) {
        _add('❌ Worker /api/chat error: ' + e.toString());
        setState(() => _running = false);
        return;
      }

      // 3) Mic permission + record 2s sample
      final recorder = AudioRecorder();
      final hasPerm = await recorder.hasPermission();
      _add('Mic permission: ' + (hasPerm ? 'granted' : 'denied'));
      if (!hasPerm) {
        _add('❌ Grant microphone permission and retry.');
        setState(() => _running = false);
        return;
      }
      final dir = await getTemporaryDirectory();
      final filePath = '${dir.path}/diag_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await recorder.start(
        const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 128000, sampleRate: 44100),
        path: filePath,
      );
      _add('Recording 2 seconds...');
      await Future.delayed(const Duration(seconds: 2));
      final path = await recorder.stop();
      if (path == null) {
        _add('❌ Recorder returned null path.');
        setState(() => _running = false);
        return;
      }
      final f = File(path);
      if (!await f.exists()) {
        _add('❌ Recorded file not found: $path');
        setState(() => _running = false);
        return;
      }
      final size = await f.length();
      _add('✅ Recorded file: $path (${size} bytes)');

      final bytes = await f.readAsBytes();

      // 4) End-to-end voice_chat
      _add('POST /api/voice_chat ...');
      try {
      _add('Worker base: ' + AppConfig.normalizedWorkerBaseUrl);
        final res = await LlmService.voiceChat(
          audio: bytes,
          mimeType: 'audio/m4a',
          openAiApiKey: key,
        );
        _add('Transcript: ' + (res.transcript ?? '(none)'));
        _add('Reply: ' + (res.reply ?? '(none)'));
        if ((res.reply ?? '').isNotEmpty) {
          _add('✅ End-to-end pipeline OK.');
        } else {
          _add('⚠ End-to-end returned empty reply. See worker logs.');
        }
      } catch (e) {
        _add('❌ Voice chat error: $e');
      }
    } finally {
      setState(() => _running = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Diagnostics')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                ElevatedButton(
                  onPressed: _running ? null : _runChecks,
                  child: const Text('Run Checks'),
                ),
                const SizedBox(width: 12),
                if (_running) const Text('Running...'),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _log.length,
              itemBuilder: (_, i) => Text(_log[i]),
            ),
          )
        ],
      ),
    );
  }
}
